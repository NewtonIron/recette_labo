# 420-326: Laboratoire 02

## Objectif
L’objectif de ce travail pratique est de :
-	Réaliser une application Mobile en utilisant ionic 7 avec Vue3 et **l’API composition**.
-	Intégrer dans un même application plusieurs des notions étudiées depuis le début de la session.
-	Rechercher de l’information technique sur Internet.

## Travail à réaliser
__DEMO__: https://vimeo.com/727134722/b9f7e724fb

Vous devez réaliser une application pour mobile qui permet d’afficher des recettes
de cuisine.

- Voir l'énoncé en PDF jointe au REPO.
- Les recettes sont disponibles sur le site : [](www.themealdb.com)
- Réaliser le projet en équipe de 1, 2 ou 3 personnes.

L'API composition est celle qui utilise:

```html
<script setup>
//...
</script>
```
